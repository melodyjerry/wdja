<?php
$nroute = 'root';
wdja_cms_init($nroute);
$nhead = $default_head;
$nfoot = $default_foot;
$ntitle = ii_itake('module.channel_title', 'lng');
?>
