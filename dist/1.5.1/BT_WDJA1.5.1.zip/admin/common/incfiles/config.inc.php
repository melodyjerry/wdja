<?php
$ngenre = ADMIN_FOLDER;
wdja_cms_init('node');
wdja_cms_admin_init();
$adms_appstr = 'admin_guide_' . $nlng;
?>
