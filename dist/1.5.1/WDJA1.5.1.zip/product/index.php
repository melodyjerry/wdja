<?php
require('../common/incfiles/common.inc.php');
require('../expansion/fields/common/incfiles/api.php');
require('common/incfiles/config.inc.php');
require('common/incfiles/module_config.inc.php');
$myhtml = wdja_cms_module();
echo $myhtml;
?>
