<?php
require('../../common/incfiles/common.inc.php');
require('../../common/incfiles/admin.inc.php');
require('common/incfiles/config.inc.php');
require('common/incfiles/interface_config.inc.php');
wdja_cms_islogin();
wdja_cms_interface();
?>
