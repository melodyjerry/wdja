﻿function emails() {
  addtxt="[email][/email]";
  addtext(addtxt);
}

function bold() {
  addtxt="[b][/b]";
  addtext(addtxt);
}

function italicize() {
  addtxt="[i][/i]";
  addtext(addtxt);
}

function quote() {
  addtxt="[quote][/quote]";
  addtext(addtxt);
}

function center() {
  addtxt="[align=center][/align]";
  addtext(addtxt);
}

function hyperlink() {
  addtxt="[url][/url]";
  addtext(addtxt);
}

function image() {
  addtxt="[img][/img]";
  addtext(addtxt);
}

function showcode() {
  addtxt="\r[code]\r[/code]";
  addtext(addtxt);
}

function underline() {
  addtxt="[u][/u]";
  addtext(addtxt);
}

function flash() {
  addtxt="[flash=500,350][/flash]";
  addtext(addtxt);
}

function cwmv() {
  addtxt="[mp=500,350][/mp]";
  addtext(addtxt);
}