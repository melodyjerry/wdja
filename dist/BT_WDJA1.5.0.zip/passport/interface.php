<?php
require('../common/incfiles/common.inc.php');
require('common/api/user.inc.php');
require('common/incfiles/config.inc.php');
require('common/incfiles/interface_config.inc.php');
wdja_cms_interface();
?>
